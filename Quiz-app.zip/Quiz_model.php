<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quiz_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_all_questions() {
        $query = $this->db->get('questions');
        return $query->result_array();
    }

    public function evaluate_answers($answers) {
        $score = 0;
        foreach ($answers as $question_id => $answer) {
            $this->db->where('id', $question_id);
            $query = $this->db->get('questions');
            $correct_answer = $query->row()->correct_answer;
            if ($answer == $correct_answer) {
                $score++;
            }
        }
        return array('score' => $score);
    }
}
?>
