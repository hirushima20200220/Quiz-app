$(document).ready(function() {
    var Question = Backbone.Model.extend({
        defaults: {
            question: '',
            options: [],
            correct_answer: ''
        }
    });

    var QuestionsCollection = Backbone.Collection.extend({
        model: Question,
        url: '/quiz/get_questions'
    });

    var QuestionView = Backbone.View.extend({
        tagName: 'div',
        className: 'question',
        template: _.template($('#question-template').html()),
        
        render: function() {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        }
    });

    var QuizView = Backbone.View.extend({
        el: '#quiz-container',

        initialize: function() {
            this.collection = new QuestionsCollection();
            this.collection.fetch({
                success: this.render.bind(this)
            });
        },

        render: function() {
            this.collection.each(this.addQuestion, this);
            return this;
        },

        addQuestion: function(question) {
            var view = new QuestionView({ model: question });
            this.$el.append(view.render().el);
        }
    });

    var quizView = new QuizView();
});

<script type="text/template" id="question-template">
    <h3><%= question %></h3>
    <ul>
        <% _.each(options, function(option) { %>
            <li><label><input type="radio" name="question_<%= id %>" value="<%= option %>"> <%= option %></label></li>
        <% }); %>
    </ul>
</script>
