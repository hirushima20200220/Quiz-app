CREATE TABLE `questions` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `question` text NOT NULL,
    `option_a` varchar(255) NOT NULL,
    `option_b` varchar(255) NOT NULL,
    `option_c` varchar(255) NOT NULL,
    `option_d` varchar(255) NOT NULL,
    `correct_answer` char(1) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
