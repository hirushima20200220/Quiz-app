<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quiz extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Quiz_model');
        $this->load->helper('url');
    }

    public function index() {
        $this->load->view('quiz_view');
    }

    public function get_questions() {
        $questions = $this->Quiz_model->get_all_questions();
        echo json_encode($questions);
    }

    public function submit_answers() {
        $answers = $this->input->post('answers');
        $result = $this->Quiz_model->evaluate_answers($answers);
        echo json_encode($result);
    }
}
?>
